cat hosts.deny | cut -d: -f2 | sort -n
cat hosts.deny | cut -d: -f2 | sort -n | grep "99" > results.txt
